===================================================
##                                              ##
##   █████████      ███████         █████████   ##
##         ███      ███    ██       ███         ##
##       ███        ███    ███      ███         ##
##     ███          ███    ███      ███  ████   ##
##   ███            ███    ██       ███    ██   ##
##   █████████      ███████         █████████   ##
##                                              ##
##  ESSE MATERIAL FAZ PARTE DA COMUNIDADE ZDG   ##
##                                              ##
##        PIRATEAR ESSA SOLUÇÃO É CRIME.        ##
##                                              ##
##    © COMUNIDADE ZDG - comunidadezdg.com.br   ##
##                                              ##
===================================================

## CRIAR SUBDOMINIO E APONTAR PARA O IP DA SUA VPS

FRONTEND_URL: frontizing.comunidadezdg.com.br
BACKEND_URL:  backizing.comunidadezdg.com.br
ADMIN: adminizing.comunidadezdg.com.br


## CHECAR PROPAGAÇÃO DO DOMÍNIO

https://dnschecker.org/

## COPIAR A PASTA PARA ROOT E RODAR OS COMANDOS ABAIXO ##

sudo chmod +x ./izing_shell/izing
cd ./izing_shell
sudo ./izing

===================================================

## APÓS A INSTALAÇÃO

## INSTALAR O CHROME
sudo su deployzdg
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo apt install -y ./google-chrome-stable_current_amd64.deb

## AJUSTA NGINX DO FRONT E ADMIN
cd /etc/nginx/sites-available/
sudo nano izing-admin-frontend
$uri $uri/
sudo nano izing-frontend
service nginx restart

## INICIAR TODOS OS CONTAINERS
sudo docker start $(docker ps -a -q)

===================================================

## MANUAL

sudo apt-get install -y libgbm-dev wget unzip fontconfig locales gconf-service libasound2 libatk1.0-0 libc6 libcairo2 libcups2 libdbus-1-3 libexpat1 libfontconfig1 libgcc1 libgconf-2-4 libgdk-pixbuf2.0-0 libglib2.0-0 libgtk-3-0 libnspr4 libpango-1.0-0 libpangocairo-1.0-0 libstdc++6 libx11-6 libx11-xcb1 libxcb1 libxcomposite1 libxcursor1 libxdamage1 libxext6 libxfixes3 libxi6 libxrandr2 libxrender1 libxss1 libxtst6 ca-certificates fonts-liberation libappindicator1 libnss3 lsb-release xdg-utils git
 
sudo apt-add-repository universe
sudo apt update
sudo apt install python2-minimal
sudo apt-get install build-essential
sudo apt update && sudo apt upgrade

curl -fsSL https://deb.nodesource.com/setup_14.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v
npm -v

adduser deployzdg
usermod -aG sudo deployzdg
su deployzdg

sudo apt install apt-transport-https ca-certificates curl software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic stable"
sudo apt update
sudo apt install docker-ce
sudo systemctl status docker
sudo usermod -aG docker ${USER}
su - ${USER}

conectar com o usuario deployzdg e enviar a pasta via ftp
sudo apt install unzip
unzip izing.zip

ou fazer o clone 
git clone https://github.com/ldurans/izing.io.git

docker run --name postgresql -e POSTGRES_USER=izing -e POSTGRES_PASSWORD=password -p 5432:5432 -v /data:/var/lib/postgresql/data -d postgres
docker run -e TZ="America/Sao_Paulo" --name redis-izing -p 6379:6379 -d --restart=always redis:latest redis-server --appendonly yes --requirepass "password"
docker run -d --name rabbitmq -p 5672:5672 -p 15672:15672 --restart=always --hostname rabbitmq -v /data:/var/lib/rabbitmq rabbitmq:3-management-alpine

docker container start postgresql
docker container start redis-izing
docker container start rabbitmq

===================================================

#NODE_ENV=prod

# ambiente
NODE_ENV=dev

# URL do backend para construção dos hooks
BACKEND_URL=http://localhost

# URL do front para liberação do cors
FRONTEND_URL=http://localhost:3003

# Porta utilizada para proxy com o serviço do backend
PROXY_PORT=3000

# Porta que o serviço do backend deverá ouvir
PORT=3000


# conexão com o banco de dados
DB_DIALECT=postgres
DB_PORT=5432
POSTGRES_HOST=localhost
POSTGRES_USER=izing
POSTGRES_PASSWORD=password
POSTGRES_DB=izing


# Chaves para criptografia do token jwt
JWT_SECRET=DPHmNRZWZ4isLF9vXkMv1QabvpcA80Rc
JWT_REFRESH_SECRET=EMPehEbrAdi7s8fGSeYzqGQbV5wrjH4i

# Dados de conexão com o REDIS
IO_REDIS_SERVER=localhost
IO_REDIS_PASSWORD=password
IO_REDIS_PORT=6379
IO_REDIS_DB_SESSION=2

#CHROME_BIN=/usr/bin/google-chrome
#CHROME_BIN=/usr/bin/google-chrome-stable
#CHROME_BIN=null

# tempo para randomização da mensagem de horário de funcionamento
MIN_SLEEP_BUSINESS_HOURS=10000
MAX_SLEEP_BUSINESS_HOURS=20000

# tempo para randomização das mensagens do bot
MIN_SLEEP_AUTO_REPLY=4000
MAX_SLEEP_AUTO_REPLY=6000

# tempo para randomização das mensagens gerais
MIN_SLEEP_INTERVAL=2000
MAX_SLEEP_INTERVAL=5000


# dados do RabbitMQ / Para não utilizar, basta comentar a var AMQP_URL
RABBITMQ_DEFAULT_USER=admin
RABBITMQ_DEFAULT_PASS=123456
# AMQP_URL='amqp://admin:123456@host.docker.internal:5672?connection_attempts=5&retry_delay=5'

# api oficial (integração em desenvolvimento)
API_URL_360=https://waba-sandbox.360dialog.io

# usado para mosrar opções não disponíveis normalmente.
ADMIN_DOMAIN=izing.io

# Dados para utilização do canal do facebook
FACEBOOK_APP_ID=3237415623048660
FACEBOOK_APP_SECRET_KEY=3266214132b8c98ac59f3e957a5efeaaa13500

===================================================

cd izing/backend
npm install --force
npm run build
docker stop $(docker ps -q)
docker container start postgresql
docker container start redis-izing
docker container start rabbitmq	
docker restart $(docker ps -a -q)
npm run db:migrate
npm run db:seed
cd ../frontend
npm install
cp .env.example .env
nano .env

===================================================

URL_API='https://backizing.comunidadezdg.com.br'
FACEBOOK_APP_ID='23156312477653241'

===================================================

sudo npm i -g @quasar/cli
sudo quasar build -P -m pwa
sudo npx quasar build -P -m pwa
sudo npm install -g pm2
cd ../backend
pm2 start dist/server.js --name izing-backend
pm2 startup ubuntu -u deployzdg
sudo env PATH=$PATH:/usr/bin pm2 startup ubuntu -u deployzdg --hp /home/deployzdg
sudo apt install nginx
sudo rm /etc/nginx/sites-enabled/default
sudo nano /etc/nginx/sites-available/izing-backend

server {
  server_name backizing.comunidadezdg.com.br;

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_cache_bypass $http_upgrade;
  }
}

sudo nano /etc/nginx/sites-available/izing-frontend

server {
  server_name frontizing.comunidadezdg.com.br;
  
  root /home/deployzdg/izing.io/frontend/dist/pwa;
  
  add_header X-Frame-Options "SAMEORIGIN";
  add_header X-XSS-Protection "1; mode=block";
  add_header X-Content-Type-Options "nosniff"; 
  
  index index.html;
  charset utf-8;
  location / {
    try_files $uri $uri/ /index.html;
  }

  access_log off;

}

sudo ln -s /etc/nginx/sites-available/izing-backend /etc/nginx/sites-enabled
sudo ln -s /etc/nginx/sites-available/izing-frontend /etc/nginx/sites-enabled
sudo nano /etc/nginx/nginx.conf

client_max_body_size 20M;
# HANDLE BIGGER UPLOADS

sudo nginx -t
sudo service nginx restart
sudo snap install --classic certbot
sudo certbot --nginx

===================================================