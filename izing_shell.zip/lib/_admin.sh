#!/bin/bash
# 
# functions for setting up app frontend

#######################################
# installed node packages
# Arguments:
#   None
#######################################
admin_node_dependencies() {
  print_banner
  printf "${WHITE} 💻 Instalando dependências do admin-frontend...${GRAY_LIGHT}"
  printf "\n\n"

  sleep 2

  sudo su - deployzdg <<EOF
  cd /home/deployzdg/izing.io/admin-frontend
  npm install
  sudo npm i -g @quasar/cli
EOF

  sleep 2
}

#######################################
# compiles frontend code
# Arguments:
#   None
#######################################
admin_node_build() {
  print_banner
  printf "${WHITE} 💻 Compilando o código do admin-frontend...${GRAY_LIGHT}"
  printf "\n\n"

  sleep 2

  sudo su - deployzdg <<EOF
  cd /home/deployzdg/izing.io/admin-frontend
  sudo quasar build -P -m pwa
  sudo npx quasar build -P -m pwa
EOF

  sleep 2
}

#######################################
# sets frontend environment variables
# Arguments:
#   None
#######################################
admin_set_env() {
  print_banner
  printf "${WHITE} 💻 Configurando variáveis de ambiente (frontend)...${GRAY_LIGHT}"
  printf "\n\n"

  sleep 2

  # ensure idempotency
  backend_url=$(echo "${backend_url/https:\/\/}")
  backend_url=${backend_url%%/*}
  backend_url=https://$backend_url

  # ensure idempotency
  admin_url=$(echo "${admin_url/https:\/\/}")
  admin_url=${admin_url%%/*}
  admin_url=https://$admin_url

sudo su - deployzdg << EOF
  cat <<[-]EOF > /home/deployzdg/izing.io/admin-frontend/.env
  ADMIN_URL=${admin_url}
  BACKEND_URL=${backend_url}
[-]EOF
EOF

  sleep 2
}

#######################################
# sets up nginx for frontend
# Arguments:
#   None
#######################################
admin_nginx_setup() {
  print_banner
  printf "${WHITE} 💻 Configurando nginx (admin-frontend)...${GRAY_LIGHT}"
  printf "\n\n"

  sleep 2

  admin_hostname=$(echo "${admin_url/https:\/\/}")

sudo su - root << EOF

cat > /etc/nginx/sites-available/izing-admin-frontend << 'END'

server {
  server_name $admin_hostname;
  
  root /home/deployzdg/izing.io/admin-frontend/dist/pwa;
  
  add_header X-Frame-Options "SAMEORIGIN";
  add_header X-XSS-Protection "1; mode=block";
  add_header X-Content-Type-Options "nosniff"; 
  
  index index.html;
  charset utf-8;
  location / {
    try_files $uri $uri/ /index.html;
  }

  access_log off;

}
END

ln -s /etc/nginx/sites-available/izing-admin-frontend /etc/nginx/sites-enabled
EOF

  sleep 2
}
